# Telecom X - Análisis de Evasión de Clientes (Churn)

Este proyecto corresponde al desafío **Telecom X**, cuyo objetivo es analizar la evasión de clientes (churn)
en una empresa de telecomunicaciones mediante el uso de **Python, Pandas, Matplotlib y Seaborn**.

## 📌 Objetivo
Identificar patrones, tendencias e insights en los datos que expliquen por qué los clientes abandonan la empresa.

## 📂 Estructura del Proyecto
- `data/`: Contiene el dataset original (`TelecomX_Data.json`).
- `notebooks/`: Jupyter Notebooks usados para el análisis.
- `outputs/`: Resultados (gráficos e informes generados).
- `docs/`: Documentación y diccionario de datos.

## 🚀 Requisitos
Instala las librerías necesarias:
```bash
pip install -r requirements.txt
```

## ▶️ Ejecución
1. Abre el notebook en `notebooks/TelecomX_EDA.ipynb`.
2. Ejecuta las celdas paso a paso para reproducir el análisis.
3. Los gráficos y resultados se guardarán en `outputs/`.

## 📊 Insights esperados
- Distribución de churn (evasión).
- Relación entre variables categóricas y churn.
- Relación entre variables numéricas y churn.
- Factores clave que explican la evasión.

## 👨‍💻 Autor
Proyecto realizado en el marco del programa **Alura LATAM - ONE**.
